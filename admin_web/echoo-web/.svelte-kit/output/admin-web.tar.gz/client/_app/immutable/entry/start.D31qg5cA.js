import{a as t}from"../chunks/entry.7PKGXZch.js";export{t as start};
